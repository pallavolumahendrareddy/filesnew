import time
import getpass
class RecordInformation :
    def __init__(self, name):
        self.record_timestamp = time.time()
        if(name is None):
            userName = getpass.getuser()
            self.record_username = userName
        else:
            self.record_username = name