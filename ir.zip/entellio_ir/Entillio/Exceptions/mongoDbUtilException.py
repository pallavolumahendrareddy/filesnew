#from Exceptions.logginException import LoggingException
from Exceptions.logginException import *


class MongoDbUtilException(LoggingException):
    def __init__(self, val):
        super().__init__(val)
        self.value = val

    def __str__(self):
        return repr(self.value)
