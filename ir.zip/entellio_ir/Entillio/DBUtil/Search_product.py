from DBUtil.crud import Crud
from bson.json_util import dumps
from config import *

def searchuuid(data):
    beacon_uuid= data
    print(beacon_uuid)
    productDao = Crud("product",None);

    result = productDao.find({"uuid": beacon_uuid})
    #resultDao=dumps(result)
    #print(resultDao)
    #return resultDao

    if (result.count() >= 1):
        product = result[result.count() -1]
        url=product["imageUrl"]

    path=Config.getconfig("server", "cloud_url")+url
    #print(path)
    resultdao = dumps(result)
    print(resultdao)
    return resultdao,path
