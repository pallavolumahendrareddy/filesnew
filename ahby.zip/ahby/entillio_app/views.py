from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.views import APIView
from rest_framework.response import Response
import json
from entillio_app.nlp import chat, parseText, getContentType
import heapq

def index(request):
    return render(request, "index.html", {})


@csrf_exempt
def query(request):
    if request.method == 'POST':
        response_text = chat(request.POST['Chat'])
        if "routelist" in response_text:
            response_text=response_text["response"]+response_text["routelist"]
        else:
            response_text=response_text["response"]
        return render(request, 'index.html', {'response_text': response_text})
    elif request.method == 'GET':
        return render(request, 'index.html')
    else:
        response_text = 'Invalid chat constructs.Contact your administrator'
        return render(request, 'index.html', {'response_text': response_text})


class query_api(APIView):
    def post(self, request):
        if 'chat' in request.data:
            response_text = chat(request.data['chat'])
            return Response({'entillio': response_text})
        else:
            response_text = 'Invalid chat constructs, Please contact application administrator.'
            return Response({'entillio': response_text})


class search(APIView):
    def post(self,request):
        jsonarray = []
        if request.method == 'POST':
            content = request.body.decode('utf-8')
            json_content = (json.loads(content))
            response_text = chat(json_content["searchstring"])
            parseUrls = parseText(response_text["response"])
            if "routelist" in response_text:
                jsontext=dict(contenttype="text/text",content=response_text["response"],routelist=response_text["routelist"])
            else:
                jsontext=dict(contenttype="text/text",content=response_text["response"])
            #jsontext = json.loads(jsontext)
            jsonarray.append(jsontext)
            if parseUrls != None and len(parseUrls) > 0:
                for url in parseUrls:
                     mime_type=getContentType(url)
                     print(mime_type)
                     jsontext=dict(contenttype=mime_type,content=url)
                     jsonarray.append(jsontext)
            response_text = jsonarray
            return Response({'entillio': response_text})
        else:
            response_text = 'Invalid chat constructs, Please contact application administrator.'
            return Response({'entillio': response_text})
