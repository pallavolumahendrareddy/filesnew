from django.apps import AppConfig


class EntillioAppConfig(AppConfig):
    name = 'entillio_app'
