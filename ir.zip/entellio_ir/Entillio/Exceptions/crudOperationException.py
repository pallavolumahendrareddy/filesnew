from Exceptions.logginException import LoggingException


class CrudOperationException(LoggingException):
    def __init__(self, val):
        super().__init__(val)
        self.value = val

    def __str__(self):
        return repr(self.value)
