import json
import os
from enum import Enum

from pymongo import MongoClient
from pymongo.errors import ConfigurationError
from pymongo.errors import InvalidName

from Exceptions import mongoDbUtilException


class __JsonKey(Enum):
    DATABASE = "database"
    DATABASE_PATH = "db_path"
    DATABASE_NAME = "db_name"

def getCollection(name):
    if (type(name) is str and len(name.strip()) > 0):
        try:
            db = __getDatabase()
            return db[name]
        except mongoDbUtilException as e:
            raise mongoDbUtilException(e)
    else:
        raise mongoDbUtilException("Collection name is not correct")

def __getDatabase():
    try:
        APP_ROOT = os.path.dirname(os.path.abspath(__file__))  #gives the current directory in which file is present
        #APP_ROOT=os.path.pardir                         #gives the parent directory
        #print(APP_ROOT)
        configFilePath = os.path.join(APP_ROOT,"../configuration.json");
        #print(configFilePath)
        with open(configFilePath) as data_file:
            data = json.load(data_file)

        datbaseRecord = data[__JsonKey.DATABASE.value]
        client = MongoClient(datbaseRecord[__JsonKey.DATABASE_PATH.value])
        db = client[datbaseRecord[__JsonKey.DATABASE_NAME.value]]

        return db
    except ConfigurationError as e:
        raise mongoDbUtilException(e)
    except InvalidName as e:
        raise mongoDbUtilException(e)
    except Exception as e:
        raise mongoDbUtilException(e)