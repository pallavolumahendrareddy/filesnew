import json

from flask import Flask,render_template, request
#from nlp import chat, parseText, getContentType
from nlp import chat, parseText, getContentType
app = Flask(__name__)

@app.route('/')
@app.route('/index.html')
def index(name=None):
	return  render_template('index.html',name=name)

@app.route('/query', methods=['POST'])
def query():
    error = None
    if request.method == 'POST':
        response_text = chat(request.form['Chat'])

    else:
        response_text = 'Invalid chat constructs.Contact your administrator'
    # the code below is executed if the request method
    # was GET or the credentials were invalid
    return render_template('index.html', response = response_text)

@app.route('/search', methods=['POST'])
def search():
    error = None
    jsonarray=[]
    if request.method == 'POST':
        content= request.get_json(force=True)
        #print(content)
        response_text = chat(content["searchstring"])
        parseUrls=parseText(response_text)
        #print(parseUrls)
        jsontext = '{ \
            "contenttype": "text/text", \
             "content": "' + response_text + '"}'
        if response_text == 'There are various routes to Udaipur from Pune. Click on the route below to know more details':
            jsontext = '{ \
                "contenttype": "text/text", \
                 "content": "' + response_text + '", \
                 "routelist": ["PUNE to ST to UDZ","PUNE to GKP to UDZ","PUNE to FDB to UDZ","PUNE to KYN to UDZ","PUNE to BHL to UDZ","PUNE to ALD to UDZ","PUNE to MTJ to UDZ","PUNE to PNVL to UDZ","PUNE to BINA to UDZ","PUNE to BRC to UDZ"] }'
        if response_text == 'SHOWINDEX':
            jsontext = '{ \
                "contenttype": "text/text", \
                 "content": "' + response_text + '", \
            "routedetail" : [    [{  \
                    "TrainNo": "17204", \
                    "Source": "PUNE", \
                    "SourceDate": "Apr 1, 2016", \
                    "DstnDate": "Apr 1, 2016", \
                    "Destination": "ST", \
                    "Duration": 470, \
                    "SrcDepartureTime": "02:05:00 AM", \
                    "DstnArivalTime": "09:55:00 AM" \
                    }, \
                    { \
                        "TrainNo": "02533", \
                        "Source": "ST", \
                        "SourceDate": "Apr 1, 2016", \
                        "DstnDate": "Apr 1, 2016", \
                        "Destination": "VAPI", \
                        "Duration": 72, \
                        "SrcDepartureTime": "01:50:00 PM", \
                        "DstnArivalTime": "03:02:00 PM" \
                        }, \
                    { \
                        "TrainNo": "12995", \
                        "Source": "VAPI", \
                        "SourceDate": "Apr 1, 2016", \
                        "DstnDate": "Apr 2, 2016", \
                        "Destination": "UDZ", \
                        "Duration": 207, \
                        "SrcDepartureTime": "06:29:00 PM", \
                        "DstnArivalTime": "08:55:00 AM" \
                        }], \
                    [{ \
                        "TrainNo": "11039", \
                        "Source": "PUNE", \
                        "SourceDate": "Apr 1, 2016", \
                        "DstnDate": "Apr 3, 2016", \
                        "Destination": "GKP", \
                        "Duration": 2630, \
                        "SrcDepartureTime": "11:20:00 PM", \
                        "DstnArivalTime": "07:10:00 PM" \
                        }, \
                        { \
                            "TrainNo": "19270", \
                            "Source": "GKP", \
                            "SourceDate": "Apr 3, 2016", \
                            "DstnDate": "Apr 4, 2016", \
                            "Destination": "BKI", \
                            "Duration": 1083, \
                            "SrcDepartureTime": "10:35:00 PM", \
                            "DstnArivalTime": "04:38:00 PM" \
                            }, \
                        { \
                            "TrainNo": "19665", \
                            "Source": "BKI", \
                            "SourceDate": "Apr 4, 2016", \
                            "DstnDate": "Apr 5, 2016", \
                            "Destination": "UDZ", \
                            "Duration": 289, \
                            "SrcDepartureTime": "09:27:00 PM", \
                            "DstnArivalTime": "06:45:00 AM" \
                            }], \
                        [{ \
                             "TrainNo": "11077", \
                             "Source": "PUNE", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "FDB", \
                             "Duration": 1581, \
                             "SrcDepartureTime": "05:20:00 PM", \
                             "DstnArivalTime": "07:41:00 PM" \
                             }, \
                         { \
                             "TrainNo": "29020", \
                             "Source": "FDB", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 3, 2016", \
                             "Destination": "NBH", \
                             "Duration": 84, \
                             "SrcDepartureTime": "10:46:00 PM", \
                             "DstnArivalTime": "12:10:00 PM" \
                             }, \
                         { \
                             "TrainNo": "19329", \
                             "Source": "NBH", \
                             "SourceDate": "Apr 3, 2016", \
                             "DstnDate": "Apr 3, 2016", \
                             "Destination": "UDZ", \
                             "Duration": 945, \
                             "SrcDepartureTime": "03:55:00 PM", \
                             "DstnArivalTime": "07:15:00 PM" \
                             }], \
                        [{ \
                             "TrainNo": "11014", \
                             "Source": "PUNE", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 1, 2016", \
                             "Destination": "KYN", \
                             "Duration": 147, \
                             "SrcDepartureTime": "10:45:00 AM", \
                             "DstnArivalTime": "01:12:00 PM" \
                             }, \
                         { \
                             "TrainNo": "12161", \
                             "Source": "KYN", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "GWL", \
                             "Duration": 1066, \
                             "SrcDepartureTime": "05:10:00 PM", \
                             "DstnArivalTime": "10:56:00 AM" \
                             }, \
                         { \
                             "TrainNo": "19665", \
                             "Source": "GWL", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 3, 2016", \
                             "Destination": "UDZ", \
                             "Duration": 289, \
                             "SrcDepartureTime": "03:45:00 PM", \
                             "DstnArivalTime": "06:45:00 AM" \
                             }], \
                        [{ \
                             "TrainNo": "22695", \
                             "Source": "PUNE", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "BHL", \
                             "Duration": 1085, \
                             "SrcDepartureTime": "07:55:00 AM", \
                             "DstnArivalTime": "02:00:00 AM" \
                             }, \
                         { \
                             "TrainNo": "19712", \
                             "Source": "BHL", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "BJNR", \
                             "Duration": 47, \
                             "SrcDepartureTime": "04:19:00 AM", \
                             "DstnArivalTime": "05:06:00 AM" \
                             }, \
                         { \
                             "TrainNo": "09721", \
                             "Source": "BJNR", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "UDZ", \
                             "Duration": 257, \
                             "SrcDepartureTime": "09:23:00 AM", \
                             "DstnArivalTime": "01:15:00 PM" \
                             }], \
                        [{ \
                             "TrainNo": "15018", \
                             "Source": "PUNE", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Mar 30, 2016", \
                             "Destination": "ALD", \
                             "Duration": 42430, \
                             "SrcDepartureTime": "04:50:00 AM", \
                             "DstnArivalTime": "04:00:00 PM" \
                             }, \
                         { \
                             "TrainNo": "12322", \
                             "Source": "ALD", \
                             "SourceDate": "Mar 30, 2016", \
                             "DstnDate": "Mar 31, 2016", \
                             "Destination": "BWN", \
                             "Duration": 794, \
                             "SrcDepartureTime": "08:58:00 PM", \
                             "DstnArivalTime": "10:12:00 AM" \
                             }, \
                         { \
                             "TrainNo": "12315", \
                             "Source": "BWN", \
                             "SourceDate": "Mar 31, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "UDZ", \
                             "Duration": 269, \
                             "SrcDepartureTime": "02:41:00 PM", \
                             "DstnArivalTime": "03:00:00 AM" \
                             }], \
                        [{ \
                             "TrainNo": "12779", \
                             "Source": "PUNE", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "MTJ", \
                             "Duration": 1430, \
                             "SrcDepartureTime": "04:10:00 AM", \
                             "DstnArivalTime": "04:00:00 AM" \
                             }, \
                         { \
                             "TrainNo": "12138", \
                             "Source": "MTJ", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "DAA", \
                             "Duration": 236, \
                             "SrcDepartureTime": "07:40:00 AM", \
                             "DstnArivalTime": "11:36:00 AM" \
                             }, \
                         { \
                             "TrainNo": "19665", \
                             "Source": "DAA", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 3, 2016", \
                             "Destination": "UDZ", \
                             "Duration": 146, \
                             "SrcDepartureTime": "02:02:00 PM", \
                             "DstnArivalTime": "06:45:00 AM" \
                             }], \
                        [{ \
                             "TrainNo": "17317", \
                             "Source": "PUNE", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 1, 2016", \
                             "Destination": "PNVL", \
                             "Duration": 172, \
                             "SrcDepartureTime": "02:55:00 AM", \
                             "DstnArivalTime": "05:47:00 AM" \
                             }, \
                         { \
                             "TrainNo": "22695", \
                             "Source": "PNVL", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "BHL", \
                             "Duration": 920, \
                             "SrcDepartureTime": "10:40:00 AM", \
                             "DstnArivalTime": "02:00:00 AM" \
                             }, \
                         { \
                             "TrainNo": "12981", \
                             "Source": "BHL", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "UDZ", \
                             "Duration": 136, \
                             "SrcDepartureTime": "04:16:00 AM", \
                             "DstnArivalTime": "07:50:00 AM" \
                             }], \
                        [{ \
                             "TrainNo": "11077", \
                             "Source": "PUNE", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "BINA", \
                             "Duration": 1075, \
                             "SrcDepartureTime": "05:20:00 PM", \
                             "DstnArivalTime": "11:15:00 AM" \
                             }, \
                         { \
                             "TrainNo": "11466", \
                             "Source": "BINA", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 3, 2016", \
                             "Destination": "DHD", \
                             "Duration": 635, \
                             "SrcDepartureTime": "04:15:00 PM", \
                             "DstnArivalTime": "02:50:00 AM" \
                             }, \
                         { \
                             "TrainNo": "22901", \
                             "Source": "DHD", \
                             "SourceDate": "Apr 3, 2016", \
                             "DstnDate": "Apr 3, 2016", \
                             "Destination": "UDZ", \
                             "Duration": 286, \
                             "SrcDepartureTime": "07:36:00 AM", \
                             "DstnArivalTime": "03:55:00 PM" \
                             }], \
                        [{ \
                             "TrainNo": "19419", \
                             "Source": "PUNE", \
                             "SourceDate": "Apr 1, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "BRC", \
                             "Duration": 583, \
                             "SrcDepartureTime": "05:25:00 PM", \
                             "DstnArivalTime": "03:08:00 AM" \
                             }, \
                         { \
                             "TrainNo": "19037", \
                             "Source": "BRC", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 2, 2016", \
                             "Destination": "BXN", \
                             "Duration": 853, \
                             "SrcDepartureTime": "05:12:00 AM", \
                             "DstnArivalTime": "07:25:00 PM" \
                             }, \
                         { \
                             "TrainNo": "12963", \
                             "Source": "BXN", \
                             "SourceDate": "Apr 2, 2016", \
                             "DstnDate": "Apr 3, 2016", \
                             "Destination": "UDZ", \
                             "Duration": 162, \
                             "SrcDepartureTime": "10:07:00 PM", \
                             "DstnArivalTime": "07:20:00 AM" \
                             }] \
                    ]}'


            print(jsontext)
        jsontext = json.loads(jsontext)
        jsonarray.append(jsontext)
        if parseUrls != None and len(parseUrls) > 0:
            for url in parseUrls:
                 mime_type=getContentType(url)
                 print(mime_type)
                 jsontext = '{ \
                 "contenttype": "' + mime_type + '", \
                 "content": "' + url + '"}'
                 jsontext = json.loads(jsontext)
                 jsonarray.append(jsontext)
        response_text = json.dumps(jsonarray)
      	#print(response_text)
    else:
        response_text = 'Invalid chat constructs.Contact your administrator'
    # the code below is executed if the request method
    # was GET or the credentials were invalid
    response_text = '{"entillio":' + response_text + '}'
    print (response_text)
    return response_text

if __name__ == '__main__':
	app.debug = True
	app.run(host="0.0.0.0", port=8196)
