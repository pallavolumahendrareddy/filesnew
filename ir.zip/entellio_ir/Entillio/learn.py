import aiml
import nltk
import math
import wikipedia
from nltk import word_tokenize
from nltk import sent_tokenize, word_tokenize
from nltk.corpus import stopwords


#nltk path= C:\Users\SG00356828\AppData\Roaming\nltk_data



def understand_text(sentence):
	#Tokenize the input message and take words out of it
	tokenized_words = word_tokenize(sentence)
	tokenized_words = [w for w in tokenized_words if w not in set(stopwords.words("english"))]	
	#Create pos tags
	pos_tagged_words = nltk.pos_tag(tokenized_words)
	#print(pos_tagged_words)
	#Create a chunked gram or a chink gram out of it
	#chunkGram = r"""WordChunk: {<NNP><NN>*<CD>*}"""
	#chunkparser = nltk.RegexpParser(chunkGram)
	#return (chunkparser.parse(pos_tagged_words))
	return pos_tagged_words


def fetch_details(sentence):
	try:
		wordlist = ""
		pos_tagged_words = understand_text(sentence)
		for word in pos_tagged_words:
				word,pos = word
				#print(word +" "+pos)
				if(pos=="NN" or pos =="NNP" or pos == "NNS" or pos=='JJ'):
					wordlist = wordlist + word + ' '
		print(wordlist)
		#code to check if required detail is available in database
		wiki_summary = wikipedia.summary(wordlist)
		if wiki_summary is not None :
			length_text = len(wiki_summary)
		else:
			wiki_summary = "Could not find enough information."

		if length_text >= 1000:
			length_text = math.floor(len(wiki_summary) * 0.4)
		else:
		    length_text = len(wiki_summary)

		print(wiki_summary.encode("utf-8")[:length_text])

		return wiki_summary.encode("utf-8")[:length_text]

	except Exception as e:
		print("Error in searching" + str(e))


