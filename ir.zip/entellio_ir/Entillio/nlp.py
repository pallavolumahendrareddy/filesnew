import re

import aiml
import urllib3
from bs4 import BeautifulSoup
#from learn import fetch_details
from learn import fetch_details

kernel = aiml.Kernel()
kernel.learn("std-startup.xml")
kernel.respond("load aiml")

sessionID = 12345
#oad the text to speech engine
#engine = pyttsx.init()

#Append new intelligence to AIML
def appendAIML(input_message,fetch_text):
	str_formation = "<category><pattern>" + input_message.upper() + "</pattern><template>" + fetch_text +"</template></category>"
	print(str_formation)

	
def chat(context):
	# Chat loop	
	try:
		while True:		
		   #input_message = input("Enter your message >> ")				
		   input_message = context	
		   #print('content ' + input_message)

		   response_text = kernel.respond(input_message,sessionID)

		   return context_capture(input_message,response_text)

	except Exception as e:
		print("Sorry, my kernel got corrupted. Please restart me", str(e))

def parseText(text):
     #print("Parse Text " + text)
     urls = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text)
     return urls

'''def getContentType(pageUrl):
    response = requests.get(pageUrl)
    content_type = response.headers['content-type']
    extension = mimetypes.guess_extension(content_type)
    return extension
'''

def getContentType(pageUrl):
    pageUrl = pageUrl[:-1]
    http = urllib3.PoolManager()
    page = http.request('GET', pageUrl)
    pageHeaders = page.headers
    print("url " + pageUrl)
    contentType = pageHeaders['content-type']
    return contentType

def context_capture(input_message,response_text):
	if response_text is not None:
		if (response_text.find("_1000", 0, len(response_text)) >= 0):		
			#Since these responses are not added into the system allow the system to learn
			fetch_text = fetch_details(input_message)
			if fetch_text is not None:
				response_text = BeautifulSoup(fetch_text,"html.parser")
				return (response_text.get_text())
				appendAIML(input_message,response_text.get_text())
			else:
				return "Sorry! Do not have information on this"
		elif (response_text.find("VIDEOBILL", 0, len(response_text)) >= 0):
			response_text = response_text.replace("VIDEOBILL","http://digitization.cloudapp.net:8080/VideoBilling/att_video_bill.mp4")
			return response_text
		elif (response_text.find("BILL", 0, len(response_text)) >= 0):
			response_text = response_text.replace("BILL","$20")
			return response_text
		elif (response_text.find("ATTURL", 0, len(response_text)) >= 0):
			response_text = response_text.replace("ATTURL","att.com")
			return response_text
		elif (response_text.find("ATT", 0, len(response_text)) >= 0):
			response_text = response_text.replace("ATT","AT&T")
			return response_text
		elif (response_text.find("UVERSE", 0, len(response_text)) >= 0):
			response_text = response_text.replace("Uverse","U-verse")
			return response_text
		elif (response_text.find("account number", 0, len(response_text)) >= 0):
			return response_text

		else:					
			return response_text
	else:
		return "Sorry! Do not have information on this"	
