import os
import json
class Config:
    def getconfig(fileName, mainKey, subKey):
        APP_ROOT = os.path.dirname(os.path.abspath(__file__))
        configFilePath = os.path.join(APP_ROOT, fileName);
        with open(configFilePath) as data_file:
            data = json.load(data_file)
        return data[mainKey][subKey]
    
    def getconfig(mainKey, subKey):
        APP_ROOT = os.path.dirname(os.path.abspath(__file__))
        configFilePath = os.path.join(APP_ROOT, "configuration.json");
        with open(configFilePath) as data_file:
            data = json.load(data_file)
        return data[mainKey][subKey]

