import json

from DBUtil.DbUtil import getCollection
from Exceptions import crudOperationException
from DBUtil.recordInformation import RecordInformation


class Crud():
    def __init__(self, collnName, username):
        self.__collection = getCollection(collnName)
        self.username = username

    def save(self, vals):
        for val in vals:
            objJson = json.dumps(val, default=lambda o: o.__dict__)
            objDict = json.loads(objJson)

            recordInfo = RecordInformation(self.username)
            recordJson = json.dumps(recordInfo,default=lambda o: o.__dict__)
            recordDict = json.loads(recordJson)

            objDict.update(recordDict)
            #print(objDict)
            self.__collection.insert_one(objDict)

    def find(self, query):
        if (type(query) is dict):
            return self.__collection.find(query)
        else:
            return self.__collection.find()

    def delete(self, query):
        if (type(query) is dict):
            return self.__collection.remove(query)
        else:
            raise crudOperationException("Provide some query")

    def update(self, query, vals):
        if (type(query) is dict):
            for val in vals:
                # Converting object to json instead of primitive type default=lambda o: o.__dict__ is used
                objJson = json.dumps(val, default=lambda o: o.__dict__)
                objDict = json.loads(objJson)
                print(objDict)
                self.__collection.update(query, objDict, True)