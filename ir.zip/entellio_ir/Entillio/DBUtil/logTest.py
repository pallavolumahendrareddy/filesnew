import sys

print (sys.path)

# try:
#     1/0
# except ArithmeticError as e:
#     raise MongoDbUtilException(e.args);
#
# try:
#     1/0
# except ArithmeticError as e:
#     raise MongoDbUtilException(e.args);