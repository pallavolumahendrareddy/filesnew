from bson.json_util import dumps

from DBUtil.crud import Crud
from config import *


def searchoffer(p_id):
    offerDao = Crud("offer",None);

    print(p_id)
    url=''
    result = offerDao.find({"productid" : p_id})

    if (result.count() >= 1):
        offer = result[result.count() -1]
        url=offer["imageurl"]

    path=Config.getconfig("server", "cloud_url")+url
    #print(path)
    resultdao = dumps(result)
    print(resultdao)
    return resultdao,path


