from log.fileLogger import DebugLog


class LoggingException(Exception):
    def __init__(self, val):
        self.value = val
        debugLog = DebugLog()
        debugLog.log(val)

    def __str__(self):
        return repr(self.value)
